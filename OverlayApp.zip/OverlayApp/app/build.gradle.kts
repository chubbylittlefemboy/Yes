plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.overlay"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.overlay"
        minSdk = 28   // needed for animated GIF decoding (ImageDecoder)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
