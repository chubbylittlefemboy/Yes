package com.example.overlay

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.IBinder
import android.view.*
import android.widget.ImageView

class OverlayService : Service() {
    companion object {
        const val STOP = "stop"
        const val REFRESH = "refresh"
        var running = false
    }

    private lateinit var wm: WindowManager
    private var view: View? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WindowManager::class.java)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        startForeground(1, notification())
        show()
        return START_STICKY
    }

    private fun show() {
        val p = getSharedPreferences("overlay", MODE_PRIVATE)
        view?.let { wm.removeView(it) }

        // Decodes photos and animated GIFs alike
        val img = p.getString("uri", null)?.let {
            try { ImageDecoder.decodeDrawable(ImageDecoder.createSource(contentResolver, Uri.parse(it))) }
            catch (e: Exception) { null }
        }
        val through = p.getBoolean("through", true)
        val L = WindowManager.LayoutParams
        val lp = WindowManager.LayoutParams(
            if (img != null) resources.displayMetrics.widthPixels * p.getInt("size", 50) / 100 else -1,
            if (img != null) -2 else -1,
            L.TYPE_APPLICATION_OVERLAY,
            L.FLAG_NOT_FOCUSABLE or L.FLAG_LAYOUT_IN_SCREEN or L.FLAG_LAYOUT_NO_LIMITS or
                (if (img == null || through) L.FLAG_NOT_TOUCHABLE else 0),
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = p.getInt("x", 0); y = p.getInt("y", 0) }

        val v: View = if (img != null) {
            ImageView(this).apply {
                setImageDrawable(img); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                (img as? AnimatedImageDrawable)?.apply { repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; start() }
                if (!through) setOnTouchListener(drag(lp, p))
            }
        } else View(this).apply { setBackgroundColor(p.getInt("color", 0xFFFF8C00.toInt())) }
        v.alpha = p.getInt("alpha", 50) / 100f

        view = v
        wm.addView(v, lp)
    }

    private fun drag(lp: WindowManager.LayoutParams, p: SharedPreferences) = object : View.OnTouchListener {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> p.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
            return true
        }
    }

    private fun notification(): Notification {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "ov")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("Overlay is on")
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    override fun onDestroy() {
        view?.let { wm.removeView(it) }
        running = false
        super.onDestroy()
    }
}
