package com.example.overlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("overlay", MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun add(v: View) = root.addView(v)
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, 32, 0, 0) }

        add(TextView(this).apply { text = "Overlay"; textSize = 28f })
        status = TextView(this); add(status)

        add(label("Content"))
        add(Button(this).apply { text = "Choose photo or GIF"; setOnClickListener { pick() } })
        add(label("Or a solid color (tap one)"))
        val row = LinearLayout(this)
        for (c in intArrayOf(0xFFFF8C00.toInt(), 0xFF000000.toInt(), 0xFF2196F3.toInt(), 0xFFE91E63.toInt()))
            row.addView(Button(this).apply {
                setBackgroundColor(c)
                setOnClickListener { prefs.edit().putInt("color", c).remove("uri").apply(); refresh(); updateStatus() }
            }, LinearLayout.LayoutParams(0, 120, 1f))
        add(row)

        add(label("Opacity (max 80% so touches can pass through on Android 12+)"))
        add(slider("alpha", 50, 5, 80))
        add(label("Photo/GIF size (% of screen width)"))
        add(slider("size", 50, 10, 100))

        add(Switch(this).apply {
            text = "Let touches pass through"; setPadding(0, 32, 0, 0)
            isChecked = prefs.getBoolean("through", true)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("through", c).apply(); refresh() }
        })
        add(TextView(this).apply { text = "Turn this off to drag a photo/GIF overlay around the screen." })

        toggle = Button(this).apply { setOnClickListener { toggleOverlay() } }
        add(toggle)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun slider(key: String, def: Int, lo: Int, hi: Int) = SeekBar(this).apply {
        max = hi; min = lo; progress = prefs.getInt(key, def)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt(key, p).apply(); refresh() }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun refresh() {
        if (OverlayService.running)
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.REFRESH))
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        if (OverlayService.running) startService(i.setAction(OverlayService.STOP)) else startForegroundService(i)
        toggle.postDelayed({ updateStatus() }, 400)
    }

    private fun pick() = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 1)

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        val uri = d?.data ?: return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        prefs.edit().putString("uri", uri.toString()).apply()
        refresh(); updateStatus()
    }

    private fun updateStatus() {
        status.text = (if (Settings.canDrawOverlays(this)) "Permission granted" else "Overlay permission needed") +
            " • " + (if (prefs.getString("uri", null) != null) "Photo/GIF" else "Solid color")
        toggle.text = if (OverlayService.running) "Stop overlay" else "Start overlay"
    }

    override fun onResume() { super.onResume(); updateStatus() }
}
